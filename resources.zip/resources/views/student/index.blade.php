@extends('layouts.student.app')
@section('body')
@endsection
