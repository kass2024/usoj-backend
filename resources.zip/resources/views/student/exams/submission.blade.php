@extends('layouts.student.app')

@section('css')
    <style>
        .submission-card {
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        .submission-header {
            background-color: #d3d9df;
            border-bottom: 1px solid #e9ecef;
        }

        .submission-details {
            padding: 20px;
        }

        .timer {
            font-weight: bold;
            color: #dc3545;
        }
    </style>
@endsection

@section('body')
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card submission-card">
                    <div class="card-header submission-header">
                        <div class="d-flex justify-content-between align-items-center">
                            <h5 class="card-title mb-0">Computer Science Fundamentals Exam</h5>
                            <div class="timer" id="examTimer">
                                Time Remaining: 60:00
                            </div>
                        </div>
                    </div>

                    <div class="card-body submission-details">
                        <form id="submissionForm" method="POST" action="{{ route('student.exams.save_submission', $exam->id) }}" enctype="multipart/form-data">
                            @csrf
                            @foreach ($questions as $question)
                                <div class="card mb-3">
                                    <div class="card-body">
                                        <h6 class="card-subtitle mb-2 text-muted">Question {{ $loop->iteration }} - {{ $question->marks }} Marks</h6>
                                        <p class="card-text">{{ $question->title }}</p>

                                        <input type="hidden" name="questions[{{ $question->id }}][question_id]" value="{{ $question->id }}">

                                        @switch($question->type)
                                            @case('radio')
                                                @foreach ($question->choices as $choice)
                                                    <div class="form-check">
                                                        <input
                                                            id="question-{{ $question->id }}-choice-{{ $choice['id'] }}"
                                                            class="form-check-input"
                                                            type="radio"
                                                            name="questions[{{ $question->id }}][answer]"
                                                            value="{{ $choice['id'] }}"
                                                            required>
                                                        <label
                                                            class="form-check-label"
                                                            for="question-{{ $question->id }}-choice-{{ $choice['id'] }}">
                                                            {{ $choice['title'] }}
                                                        </label>
                                                    </div>
                                                @endforeach
                                                @break

                                            @case('checkbox')
                                                @foreach ($question->choices as $choice)
                                                    <div class="form-check">
                                                        <input
                                                            id="question-{{ $question->id }}-choice-{{ $choice['id'] }}"
                                                            class="form-check-input"
                                                            type="checkbox"
                                                            name="questions[{{ $question->id }}][answer][]"
                                                            value="{{ $choice['id'] }}">
                                                        <label
                                                            class="form-check-label"
                                                            for="question-{{ $question->id }}-choice-{{ $choice['id'] }}">
                                                            {{ $choice['title'] }}
                                                        </label>
                                                    </div>
                                                @endforeach
                                                @break

                                            @case('open')
                                                <textarea
                                                    id="question-{{ $question->id }}-open-answer"
                                                    class="form-control"
                                                    rows="4"
                                                    name="questions[{{ $question->id }}][answer]"
                                                    placeholder="Write your explanation here..."
                                                    required></textarea>
                                                @break

                                            @case('file')
                                                <input
                                                    id="question-{{ $question->id }}-file"
                                                    type="file"
                                                    class="form-control"
                                                    name="questions[{{ $question->id }}][file]"
                                                    required />
                                                @break
                                        @endswitch
                                    </div>
                                </div>
                            @endforeach

                            <div class="text-end mt-4">
                                <button type="submit" class="btn btn-primary">
                                    Submit Exam
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('js')
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const timerElement = document.getElementById('examTimer');
            let timeRemaining = 60 * 60; // 60 minutes

            function updateTimer() {
                const minutes = Math.floor(timeRemaining / 60);
                const seconds = timeRemaining % 60;
                timerElement.textContent = `Time Remaining: ${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;

                if (timeRemaining <= 0) {
                    document.getElementById('submissionForm').submit();
                    return;
                }

                timeRemaining--;
                setTimeout(updateTimer, 1000);
            }

            updateTimer();
        });
    </script>
@endsection
