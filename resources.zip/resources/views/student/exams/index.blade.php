@extends('layouts.student.app')
@section('body')
    <div class="row">
        <div class="col-md-12">
            <div class="card" id="List">
                <div class="card-header border-bottom-dashed">
                    <div class="row g-4 align-items-center">
                        <div class="col-sm">
                            <div>
                                <h5 class="card-title mb-0">Total examzes</h5>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card-body">
                    <table class="table align-middle" id="modules" style="width: 100%">
                        <thead class="table-light text-muted">
                            <tr>
                                <th scope="col" style="width: 20px;">#</th>
                                <th data-sort="course">Course</th>
                                <th data-sort="exam">Exam</th>
                                <th data-sort="questions">Questions</th>
                                <th data-sort="date">Date Time</th>
                                <th data-sort="status">Status</th>
                                <th data-sort="marks_obtained">Marks Obtained</th>
                                <th data-sort="action">Action</th>
                            </tr>
                        </thead>
                        <tbody class="list">
                            @foreach ($exams as $exam)
                                @php
                                    $submission = $exam->student_submission(auth()->guard('student')->id());
                                    $status = $submission ? 'Completed' : 'Not Started';
                                    $marksObtained = $submission ? $submission->marks_obtained : 'N/A';
                                @endphp
                                <tr>
                                    <td>{{ $loop->iteration }}</td>
                                    <td class="course">{{ $exam->module->course->name }}</td>
                                    <td class="exam">{{ $exam->title }}</td>
                                    <td class="questions">{{ $exam->questions->count() }}</td>
                                    <td class="date">{{ $exam->start_date->format('Y-m-d H:i') }} -
                                        {{ $exam->end_date->format('H:i:s') }}</td>
                                    <td class="status">{{ $status }}</td>
                                    <td class="marks_obtained">{{ $marksObtained }} / {{ $exam->questions->sum('marks') }}</td>
                                    <td class="action">
                                        @if (!$submission)
                                            <a href="{{ route('student.exams.submission', $exam->id) }}"
                                                class="btn btn-primary btn-sm">Start</a>
                                        @else
                                            <a href="{{ route('student.exams.view_submission', $submission->id) }}"
                                                class="btn btn-success btn-sm">Preview</a>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
@endsection
@section('css')
    @include('layouts.datatable.css-without-bottons')
    {{-- @include('layouts.datatable.css-with-bottons') --}}
@endsection
@section('js')
    <!--datatable js-->
    @include('layouts.datatable.js-without-bottons')
    {{-- @include('layouts.datatable.js-with-bottons') --}}
    <script>
        // $(document).ready(function() {
        //     $('#modules').DataTable()
        // });
    </script>
@endsection
