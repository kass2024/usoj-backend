<div>
    <p class="mb-0">&copy;
        <script>
            document.write(new Date().getFullYear())
        </script> Institut Supérieur de Technologie. Design & Develop by Eric
    </p>
</div>
