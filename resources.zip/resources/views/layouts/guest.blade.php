<!doctype html>
<html lang="en" data-layout="vertical" data-topbar="light" data-sidebar="dark" data-sidebar-size="lg" data-sidebar-image="none" data-preloader="disable">
<head>
    <meta charset="utf-8" />
    <title>{{ config('app.name', 'University E-learning') }}</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta content="University E-learning" name="description" />
    <meta content="BmgCodes" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="/images/academy.png"?v=2>

    <!-- Layout config Js -->
    {{-- <script src="/assets/js/layout.js"></script> --}}
    <!-- Bootstrap Css -->
       <script src="{{asset('assets/js/layout.js')}}"></script>
    <!-- Bootstrap Css -->
    <link href="{{asset('assets/css/bootstrap.min.css')}}" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href=" {{asset('assets/css/icons.min.css')}}" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="{{asset('assets/css/app.min.css')}}" rel="stylesheet" type="text/css" />
    <!-- custom Css-->
    <link href=" {{asset('assets/css/custom.min.css')}}" rel="stylesheet" type="text/css" />
    <!-- custom Css-->
    {{-- <link href="/assets/css/custom.min.css" rel="stylesheet" type="text/css" /> --}}

</head>

<body>

    <div class="auth-page-wrapper pt-5">
        <!-- auth page bg -->
        <div class="auth-one-bg-position auth-one-bg" id="auth-particles">
            <div class="bg-overlay"></div>

            <div class="shape">
                <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 1440 120">
                    <path d="M 0,36 C 144,53.6 432,123.2 720,124 C 1008,124.8 1296,56.8 1440,40L1440 140L0 140z"></path>
                </svg>
            </div>
        </div>

        <!-- auth page content -->
        <div class="auth-page-content">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="text-center mt-sm-5 mb-4 text-white-50">
                            <div>
                                <a href="{{ route('login') }}" class="d-inline-block auth-logo">
                                    <img src="{{ asset('images/academy.png') }}" alt="" height="50">
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- end row -->

                <div class="row justify-content-center">
                    <div class="col-md-8 col-lg-6 col-xl-5">
                        {{ $slot }}
                        <!-- end card -->

                    </div>
                </div>
                <!-- end row -->
            </div>
            <!-- end container -->
        </div>
        <!-- end auth page content -->

        <!-- footer -->
        <footer class="footer">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="text-center">
                            <x-footer-label />
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- end Footer -->

    {{-- <script src="/assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script> --}}
    {{-- <script src="/assets/libs/simplebar/simplebar.min.js"></script> --}}
    {{-- <script src="/assets/libs/node-waves/waves.min.js"></script> --}}
    {{-- <script src="/assets/libs/feather-icons/feather.min.js"></script> --}}
    {{-- <script src="/assets/js/pages/plugins/lord-icon-2.1.0.js"></script> --}}
    {{-- <script src="/assets/js/plugins.js"></script> --}}
    {{-- <script src="/assets/libs/particles.js/particles.js"></script> --}}
    {{-- <script src="/assets/js/pages/particles.app.js"></script> --}}
    <script src="{{ asset('assets/js/pages/password-addon.init.js')}}"></script>
</body>
</html>
