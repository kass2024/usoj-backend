@extends('layouts.app')

@section('css')
    <style>
        .stat-card {
            transition: transform 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .activity-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 8px;
        }
    </style>
@endsection

@section('body')
    <div class="container-fluid">
        <!-- Page Title -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-center">
                    <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
                    <div class="d-flex align-items-center">
                        <div class="position-relative me-3">
                            <input type="text" class="form-control" placeholder="Search...">
                            <i class="bi bi-search position-absolute top-50 end-0 translate-middle-y me-2"></i>
                        </div>
                        <div class="dropdown">
                            <button class="btn position-relative" type="button" data-bs-toggle="dropdown">
                                <i class="bi bi-bell fs-5"></i>
                                <span
                                    class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                    3
                                </span>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="#">New student enrollment</a></li>
                                <li><a class="dropdown-item" href="#">Course update</a></li>
                                <li><a class="dropdown-item" href="#">System maintenance</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Stats Cards -->
        <div class="row g-4 mb-4">
            <div class="col-xl-3 col-md-6">
                <div class="card stat-card border-start border-4 border-primary">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-2">Total Students</h6>
                                <h4 class="mb-0">12,456</h4>
                                <div class="small mt-2 text-success">
                                    <i class="bi bi-arrow-up"></i> 12% increase
                                </div>
                            </div>
                            <div class="bg-primary bg-opacity-10 rounded-circle p-3">
                                <i class="bi bi-people fs-4 text-primary"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="card stat-card border-start border-4 border-success">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-2">Total Courses</h6>
                                <h4 class="mb-0">284</h4>
                                <div class="small mt-2 text-success">
                                    <i class="bi bi-arrow-up"></i> 5% increase
                                </div>
                            </div>
                            <div class="bg-success bg-opacity-10 rounded-circle p-3">
                                <i class="bi bi-book fs-4 text-success"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="card stat-card border-start border-4 border-info">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-2">Departments</h6>
                                <h4 class="mb-0">16</h4>
                                <div class="small mt-2 text-info">
                                    <i class="bi bi-arrow-right"></i> No change
                                </div>
                            </div>
                            <div class="bg-info bg-opacity-10 rounded-circle p-3">
                                <i class="bi bi-building fs-4 text-info"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="card stat-card border-start border-4 border-warning">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center">
                            <div>
                                <h6 class="text-muted mb-2">Faculty Members</h6>
                                <h4 class="mb-0">426</h4>
                                <div class="small mt-2 text-danger">
                                    <i class="bi bi-arrow-down"></i> 2% decrease
                                </div>
                            </div>
                            <div class="bg-warning bg-opacity-10 rounded-circle p-3">
                                <i class="bi bi-person-workspace fs-4 text-warning"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Charts -->
        <div class="row mb-4">
            <div class="col-xl-8 mb-4 mb-xl-0">
                <div class="card h-100">
                    <div class="card-header bg-transparent">
                        <h5 class="card-title mb-0">Student Enrollment Trend</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="enrollmentChart" style="height: 300px;"></canvas>
                    </div>
                </div>
            </div>
            <div class="col-xl-4">
                <div class="card h-100">
                    <div class="card-header bg-transparent">
                        <h5 class="card-title mb-0">Students by Department</h5>
                    </div>
                    <div class="card-body">
                        <canvas id="departmentChart" style="height: 300px;"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Activities and Department List -->
        {{-- <div class="row">
            <div class="col-xl-6 mb-4">
                <div class="card h-100">
                    <div class="card-header bg-transparent">
                        <h5 class="card-title mb-0">Recent Activities</h5>
                    </div>
                    <div class="card-body">
                        <div class="list-group list-group-flush">
                            <div class="list-group-item border-0 px-0">
                                <div class="d-flex align-items-center">
                                    <span class="activity-dot bg-primary"></span>
                                    <div>
                                        <h6 class="mb-1">New course 'Advanced AI' added</h6>
                                        <small class="text-muted">2 hours ago</small>
                                    </div>
                                </div>
                            </div>
                            <div class="list-group-item border-0 px-0">
                                <div class="d-flex align-items-center">
                                    <span class="activity-dot bg-success"></span>
                                    <div>
                                        <h6 class="mb-1">Professor Smith updated syllabus</h6>
                                        <small class="text-muted">4 hours ago</small>
                                    </div>
                                </div>
                            </div>
                            <div class="list-group-item border-0 px-0">
                                <div class="d-flex align-items-center">
                                    <span class="activity-dot bg-info"></span>
                                    <div>
                                        <h6 class="mb-1">25 new students enrolled</h6>
                                        <small class="text-muted">5 hours ago</small>
                                    </div>
                                </div>
                            </div>
                            <div class="list-group-item border-0 px-0">
                                <div class="d-flex align-items-center">
                                    <span class="activity-dot bg-warning"></span>
                                    <div>
                                        <h6 class="mb-1">System maintenance scheduled</h6>
                                        <small class="text-muted">6 hours ago</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-6 mb-4">
                <div class="card h-100">
                    <div class="card-header bg-transparent d-flex justify-content-between align-items-center">
                        <h5 class="card-title mb-0">Departments</h5>
                        <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#departmentModal">
                            <i class="bi bi-plus"></i> Add Department
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Students</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>Computer Science</td>
                                        <td>2,800</td>
                                        <td><span class="badge bg-success">Active</span></td>
                                        <td>
                                            <button class="btn btn-sm btn-primary me-1"><i
                                                    class="bi bi-pencil"></i></button>
                                            <button class="btn btn-sm btn-danger"><i class="bi bi-trash"></i></button>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Engineering</td>
                                        <td>2,400</td>
                                        <td><span class="badge bg-success">Active</span></td>
                                        <td>
                                            <button class="btn btn-sm btn-primary me-1"><i
                                                    class="bi bi-pencil"></i></button>
                                            <button class="btn btn-sm btn-danger"><i class="bi bi-trash"></i></button>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Business</td>
                                        <td>2,000</td>
                                        <td><span class="badge bg-success">Active</span></td>
                                        <td>
                                            <button class="btn btn-sm btn-primary me-1"><i
                                                    class="bi bi-pencil"></i></button>
                                            <button class="btn btn-sm btn-danger"><i class="bi bi-trash"></i></button>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Medicine</td>
                                        <td>1,600</td>
                                        <td><span class="badge bg-danger">Inactive</span></td>
                                        <td>
                                            <button class="btn btn-sm btn-primary me-1"><i
                                                    class="bi bi-pencil"></i></button>
                                            <button class="btn btn-sm btn-danger"><i class="bi bi-trash"></i></button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div> --}}
    </div>

@endsection

@section('js')

@endsection
