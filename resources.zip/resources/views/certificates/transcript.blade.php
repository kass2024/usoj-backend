<!DOCTYPE html>
<html>

<head>
    <title>Academic Transcript</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table,
        th,
        td {
            border: 1px solid black;
        }

        th,
        td {
            padding: 5px;
            text-align: center;
        }

        .header {
            text-align: center;
            margin-bottom: 20px;
        }

        .bold {
            font-weight: bold;
        }

        .year-title {
            background-color: #f0f0f0;
            font-weight: bold;
            text-align: left;
            padding: 8px;
            margin-top: 20px;
        }
    </style>
</head>

<body>
    @foreach ($courses as $academicYear => $courseData)
        <img style="width: 100%;" src="{{ public_path("/images/transcript-header.png") }}" alt="">
        <div class="header">
            <h3>ACADEMIC TRANSCRIPT</h3>
        </div>

        <p><span class="bold">Name:</span> {{ $student->fname }}</p>
        <p><span class="bold">Surname:</span> {{ $student->lname }}</p>
        <p><span class="bold">Reg.Number:</span> {{ $student->reg_number }}</p>
        <p><span class="bold">Department:</span> {{ $student->department->name }}</p>
        <p><span class="bold">Degree Level:</span> {{ $student->degree_level->name }}</p>

        <div class="year-title">{{ $academicYear }}</div>
        <table>
            <thead>
                <tr>
                    <th>Code</th>
                    <th>Course Name</th>
                    <th>Credits</th>
                    <th>Marks/20</th>
                    <th>Credit Max</th>
                    <th>Percentage</th>
                </tr>
            </thead>
            <tbody>
                @php
                    $i = 0;
                    $totalPercentage = 0;
                    $totalCredMax = 0;
                @endphp
                @foreach ($courseData as $course)
                    @php
                        $i++;
                        $totalPercentage += $course['percentage'];
                        $totalCredMax += $course['credit_max'];
                    @endphp
                    <tr>
                        <td>{{ $course['code'] }}</td>
                        <td style="text-align:left">{{ $course['name'] }}</td>
                        <td>{{ $course['credits'] }}</td>
                        <td>{{ $course['marks'] }}</td>
                        <td>{{ $course['credit_max'] }}</td>
                        <td>{{ $course['percentage'] }}</td>
                    </tr>
                @endforeach
                <!-- for total -->
                <tr>
                    <td colspan="2"></td>
                    <td></td>
                    <td></td>
                    <td>{{  $totalCredMax }}</td>
                    <td>{{ round($totalPercentage / $i, 2) }}</td>
                </tr>
                <tr>
                    <td>Verdict</td>
                    <td colspan="5" style="font-style:bold">
                        <b>Promoted</b>
                    </td>
                </tr>
            </tbody>
        </table>
        <table style="border: none;">
            <tr style="border: none;">
                <td style="border: none;"></td>
                <td style="border: none;">
                    <div>
                        <p>Ouagadougou, {{ now()->format("d") }}<sup>th</sup> {{ now()->format("F") }}
                            {{ now()->format("Y") }}
                        </p>
                        <p>Director General</p>
                        <p><b>Dr Issa COMPAORE</b></p>
                        <P>Officer of Came's International Order of Academic Palms</P>
                    </div>
                </td>
            </tr>
        </table>
        <img style="width: 100%;" src="{{ public_path("/images/transcript-footer.png") }}" alt="">
    @endforeach
</body>

</html>