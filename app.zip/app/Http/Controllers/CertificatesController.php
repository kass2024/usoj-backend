<?php

namespace App\Http\Controllers;

use App\Models\Student;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;


class CertificatesController extends Controller
{
    public function index(Request $request)
    {
        return view("certificates.index");
    }

    public function verifyRegNumber(Request $request)
    {
        if (!$request->filled("regNumber")) {
            return redirect()->back()->with('error', 'Registration number is required');
        }

        // get student with their department
        $student = Student::with('department')
            ->where('reg_number', $request->input("regNumber"))
            ->first();

        if (!$student) {
            return redirect()->back()->with('error', 'Student not found');
        }

        // return $student;

        return view("certificates.review", [
            "student" => $student
        ]);
    }




    /**
     * Generate academic transcript PDF for a student
     */


    public function generateTranscript(Request $request, $studentId)
    {
        // Load student with related data, including academic_year
        $student = Student::with([
            'department',
            'degree_level',
            'class_students.class_year.academic_year', // <-- Add this line
            'class_students.class_year.modules.assignments.submissions',
            'class_students.class_year.modules.quizzes.submissions',
            'class_students.class_year.modules.exams.submissions',
            'class_students.class_year.modules.course',
        ])->findOrFail($studentId);

        // Prepare data for PDF
        $transcriptData = [
            'student' => $student,
            'courses' => $this->getStudentCourses($student),
        ];

        // Render the view for testing
        // return view('certificates.transcript', $transcriptData);

        $pdf = Pdf::loadView('certificates.transcript', $transcriptData)
            ->setPaper("a4", "portrait");
        return $pdf->stream($student->reg_number . '_transcript.pdf');
    }

    /**
     * Helper function to gather all student courses with marks
     */
    private function getStudentCourses($student)
    {
        $groupedCourses = [];

        foreach ($student->class_students as $classStudent) {
            $classYear = $classStudent->class_year;
            $yearName = $classYear->year_name ?? 'Unknown Year';

            $modules = $classYear->modules;
            foreach ($modules as $module) {
                // Gather all submissions for this module
                $course = $module->course;
                if (!$course)
                    continue;

                $totalMarks = 0;
                $maxMarks = 0;
                $hasSubmission = false;

                // Assignments
                foreach ($module->assignments as $assignment) {
                    $submission = $assignment->submissions->where('student_id', $student->id)->first();
                    if ($submission) {
                        $totalMarks += $submission->marks_obtained;
                        $maxMarks += 30;
                        $hasSubmission = true;
                    }
                }
                // Quizzes
                foreach ($module->quizzes as $quiz) {
                    $submission = $quiz->submissions->where('student_id', $student->id)->first();
                    if ($submission) {
                        $totalMarks += $submission->marks_obtained;
                        $maxMarks += 30;
                        $hasSubmission = true;
                    }
                }
                // Exams
                foreach ($module->exams as $exam) {
                    $submission = $exam->submissions->where('student_id', $student->id)->first();
                    if ($submission) {
                        $totalMarks += $submission->marks_obtained;
                        $maxMarks += 40;
                        $hasSubmission = true;
                    }
                }

                if ($hasSubmission) {
                    // Calculate marks over 20 (scale total marks to 20 if maxMarks > 0)
                    $marksOver20 = $maxMarks > 0 ? round(($totalMarks / $maxMarks) * 20, 2) : 0;
                    $percentage = $maxMarks > 0 ? round(($totalMarks / $maxMarks) * 100, 2) : 0;

                    $groupedCourses[$yearName][$course->code] = [
                        'code' => $course->code,
                        'name' => $course->name,
                        'credits' => $course->credits,
                        'marks' => $marksOver20,
                        'credit_max' => $course->credits * 20,
                        'percentage' => $percentage,
                    ];
                }
            }
        }

        // If you want to reset array keys (remove course code as key):
        foreach ($groupedCourses as $year => $courses) {
            $groupedCourses[$year] = array_values($courses);
        }

        return $groupedCourses;
    }

    private function getSubmissions($module, $student, $type)
    {
        $results = [];
        foreach ($module->$type as $item) {
            $submission = $item->submissions->where('student_id', $student->id)->first();

            $courseName = $module->course->name ?? 'N/A'; // Get the course name

            $results[] = [
                'code' => $module->course->code ?? 'N/A',
                'name' => $courseName, // Use course name instead of item title
                'credits' => $module->course->credits ?? 0,
                'marks' => $submission->marks_obtained ?? 0,
                'credit_max' => ($module->course->credits ?? 0) * 20,
                'percentage' => $submission ? round(($submission->marks_obtained / 60) * 100) : 0,
            ];
        }
        return $results;
    }


}
