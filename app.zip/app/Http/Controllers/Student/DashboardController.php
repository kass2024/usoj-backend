<?php

namespace App\Http\Controllers\Student;

use App\Models\Lesson;
use App\Models\Modules;
use App\Models\ClassStudent;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    //
    public function dashboard()
    {
        return view('student.index');
    }
    public function module($id)
    {
        $module = Modules::findOrFail($id);
        $lessons = Lesson::where('module_id', $id)->get();
        return view('student.module', compact('module', 'lessons'));
    }

}
