<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Department extends Model
{
    use HasFactory;
    protected $fillable = ['name', 'abbr', 'slug', 'description', 'school_id', 'status'];
    public function school()
    {
        return $this->belongsTo(School::class);
    }
}
