<?php

use App\Http\Controllers\CertificatesController;

Route::controller(CertificatesController::class)
    ->middleware("auth")
    ->prefix("certificates")
    ->name("certificates.")
    ->group(function () {

        Route::get("/", "index")->name("index");
        Route::post("/", "verifyRegNumber")->name("verify");
        Route::get("/{id}/transcript", "generateTranscript")->name("transcript");

    });