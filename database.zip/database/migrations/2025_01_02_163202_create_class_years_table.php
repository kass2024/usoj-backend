<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('class_years', function (Blueprint $table) {
            $table->id();
            $table->string('year_name');
            $table->foreignId('department_id')->constrained()->onDelete('restrict');
            $table->foreignId('degree_level_id')->constrained()->onDelete('restrict');
            $table->integer('semester');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('class_years');
    }
};
